package model;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Point;

public class Rombo extends ClosedFigure {

    private static final long serialVersionUID = 1L;

    public Rombo(Point position, Dimension size) {
        super(position, size);
    }

    @Override
    public void doPaint(Graphics2D g) {

        Point pt = getPosition();
        Dimension sz = getSize();
        g.drawLine(pt.x, pt.y + (sz.height / 2), pt.x + (sz.width) / 2, pt.y);
        g.drawLine(pt.x + (sz.width) / 2, pt.y, pt.x + (sz.width), pt.y + (sz.height / 2));
        g.drawLine(pt.x + (sz.width), pt.y + (sz.height) / 2, pt.x + (sz.width / 2), pt.y + sz.height);
        g.drawLine(pt.x + (sz.width / 2), pt.y + sz.height, pt.x, pt.y + (sz.height / 2));
    }

}
