/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.suite;

import controller.App;
import static controller.App.APPNAME;
import static controller.App.getInstance;
import editortexto.EditorTexto;
import editortexto.InterfazUsuario;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuBar;
import javax.swing.SwingUtilities;
import model.Drawing;
import view.MainFrame;

/**
 *
 * @author Nicolás
 */
public class ActionListenerDibujo implements ActionListener {

    App app = new App();
    Drawing drawing = new Drawing();
    MainFrame frame;

    public ActionListenerDibujo(App app) {
        this.app = app;

    }

    public void actionPerformed(ActionEvent e) {
        App app = getInstance();
        app.setup();
    }
}
