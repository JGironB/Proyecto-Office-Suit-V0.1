/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.suite;

import editortexto.EditorTexto;
import editortexto.InterfazUsuario;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

/**
 *
 * @author Nicolás
 */
public class ActionListenerTexto implements ActionListener {

    EditorTexto editorTexto;

    public ActionListenerTexto(EditorTexto editorTexto) {
        this.editorTexto = editorTexto;

    }

    public void actionPerformed(ActionEvent e) {
        EditorTexto editorTexto = new EditorTexto();
        
        JMenuBar barraMenu = new JMenuBar();

        InterfazUsuario ui = new InterfazUsuario();
        SwingUtilities.invokeLater(ui);
        
        
    }
}
