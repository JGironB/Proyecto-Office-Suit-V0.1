package view;

public interface ToolInterface
{

	public static final int LINETOOL = 0;
	public static final int RECTTOOL = 1;
	public static final int ELLITOOL = 2;
	public static final int TEXTTOOL = 3;
	public static final int SELETOOL = 4;
	public static final int MOVETOOL = 5;
	public static final int RESIZETOOL = 6;
	public static final int ROMBTOOL = 7;
	public static final int NUMTOOLS = 8;
	

}
