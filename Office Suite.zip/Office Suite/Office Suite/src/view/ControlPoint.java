package view;

import java.awt.Cursor;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.Serializable;

import utils.IShape;

public class ControlPoint implements IShape, Serializable {

    static enum Coordinate {

        N, NE, E, SE, S, SW, W, NW
    }

    // v0.15
    public ControlPoint(BoundBox bbox, BoundBox norm, Coordinate coord) {
        this.bbox = bbox;
        this.norm = norm;
        this.coord = coord;
    }

    @Override
    public void doPaint(Graphics2D g) {
        Point pt = getPosition();
        g.fillRect(pt.x - HSIZE, pt.y - HSIZE, 2 * HSIZE + 1, 2 * HSIZE + 1);
    }

    // v0.15
    private Point getPosition() {
        int x = 0;
        int y = 0;

        switch (coord) {
            case N:
                x = norm.x + norm.width / 2;
                y = norm.y;
                break;
            case NE:
                x = norm.x + norm.width;
                y = norm.y;
                break;
            case E:
                x = norm.x + norm.width;
                y = norm.y + norm.height / 2;
                break;
            case SE:
                x = norm.x + norm.width;
                y = norm.y + norm.height;
                break;
            case S:
                x = norm.x + norm.width / 2;
                y = norm.y + norm.height;
                break;
            case SW:
                x = norm.x;
                y = norm.y + norm.height;
                break;
            case W:
                x = norm.x;
                y = norm.y + norm.height / 2;
                break;
            case NW:
                x = norm.x;
                y = norm.y;
                break;
        }

        return new Point(x, y);
    }

    public Cursor getCursor() // v0.15
    {
        Cursor c = null;

        switch (coord) {
            case N:
            case S:
                c = Cursor.getPredefinedCursor(Cursor.N_RESIZE_CURSOR);
                break;
            case NE:
                c = Cursor.getPredefinedCursor(Cursor.NE_RESIZE_CURSOR);
                break;
            case SW:
                c = Cursor.getPredefinedCursor(Cursor.SW_RESIZE_CURSOR);
                break;
            case E:
            case W:
                c = Cursor.getPredefinedCursor(Cursor.E_RESIZE_CURSOR);
                break;
            case NW:
                c = Cursor.getPredefinedCursor(Cursor.NW_RESIZE_CURSOR);
                break;
            case SE:
                c = Cursor.getPredefinedCursor(Cursor.SE_RESIZE_CURSOR);
                break;
        }

        return c;
    }

    public boolean contains(Point point) {
        Point pt = getPosition();
        Rectangle r = new Rectangle(pt.x - 2 * HSIZE, pt.y - 2 * HSIZE, 4 * HSIZE + 1, 4 * HSIZE + 1);

        return r.contains(point);
    }

    // bbox != norm => line
    // bbox.getWidth() > 0 => x origin at left, bbox.getWidth() < 0 => x origin at right
    // bbox.getHeight() > 0 => y origin at top, bbox.getHeight() < 0 => y origin at bottom
    public void move(int dx, int dy) {
        switch (coord) {

            case N:
                norm.doMove(0, +dy);
                norm.doResize(0, -dy);
                if (bbox != norm) { // v0.16

                    bbox.moveOrigin(0, bbox.getHeight() > 0 ? +dy : 0);
                    bbox.doResize(0, bbox.getHeight() > 0 ? -dy : +dy);
                }
                break;

            case NE:
                norm.doMove(0, +dy);
                norm.doResize(dx, -dy);
                if (bbox != norm) { // v0.16

                    bbox.moveOrigin(bbox.getWidth() > 0 ? 0 : +dx, bbox.getHeight() > 0 ? +dy : 0);
                    bbox.doResize(bbox.getWidth() > 0 ? +dx : -dx, bbox.getHeight() > 0 ? -dy : +dy);
                }
                break;

            case E:
                norm.doResize(+dx, 0); // v0.15
                if (bbox != norm) {

                    bbox.moveOrigin(bbox.getWidth() > 0 ? 0 : +dx, 0);
                    bbox.doResize(bbox.getWidth() > 0 ? +dx : -dx, 0);
                }
                break;

            case SE:
                norm.doResize(+dx, +dy);
                if (bbox != norm) { // v0.16

                    bbox.moveOrigin(bbox.getWidth() > 0 ? 0 : +dx, bbox.getHeight() > 0 ? 0 : +dy);
                    bbox.doResize(bbox.getWidth() > 0 ? +dx : -dx, bbox.getHeight() > 0 ? +dy : -dy);
                }
                break;

            case S:
                norm.doResize(0, +dy);
                if (bbox != norm) { // v0.16

                    bbox.moveOrigin(0, bbox.getHeight() > 0 ? 0 : +dy);
                    bbox.doResize(0, bbox.getHeight() > 0 ? +dy : -dy);
                }
                break;

            case SW:
                norm.doMove(+dx, 0);
                norm.doResize(-dx, +dy); // v0.15
                if (bbox != norm) { // v0.16

                    bbox.moveOrigin(bbox.getWidth() > 0 ? +dx : 0, bbox.getHeight() > 0 ? 0 : +dy);
                    bbox.doResize(bbox.getWidth() > 0 ? -dx : +dx, bbox.getHeight() > 0 ? +dy : -dy);
                }
                break;

            case W:
                norm.doMove(+dx, 0);
                norm.doResize(-dx, 0);
                if (bbox != norm) { // v0.16

                    bbox.moveOrigin(bbox.getWidth() > 0 ? +dx : 0, 0);
                    bbox.doResize(bbox.getWidth() > 0 ? -dx : +dx, 0);
                }
                break;

            case NW:
                norm.doMove(+dx, +dy);
                norm.doResize(-dx, -dy);
                if (bbox != norm) { // v0.16

                    bbox.moveOrigin(bbox.getWidth() > 0 ? +dx : 0, bbox.getHeight() > 0 ? +dy : 0);
                    bbox.doResize(bbox.getWidth() > 0 ? -dx : +dx, bbox.getHeight() > 0 ? -dy : +dy);
                }
                break;
        }
    }

    private Coordinate coord;

    private BoundBox bbox;
    private BoundBox norm; // v0.15

    public static final int HSIZE = 3;
}
