/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.suite;

import editortexto.EditorTexto;
import controller.App;
import java.awt.*;
import java.net.URL;
import javax.swing.*;
/**
 *
 * @author juamp
 */
public class LaminaBotones extends JPanel{
    
    public LaminaBotones()
    {
        
        URL rutaLogoCalculadora = UserInterface.class.getResource("LogoCalculadora.png");
        URL rutaLogoTexto = UserInterface.class.getResource("LogoTexto.png");
        URL rutaLogoImagen = UserInterface.class.getResource("LogoImagen.png");
        
        GridLayout layout = new GridLayout(9, 0);
        setLayout(layout);

       
        JTextArea space = new JTextArea();
        JTextArea text = new JTextArea("Bienvenido a Suite Office V 0.1, la aplicación encargada de hacer su");
        JTextArea text2 = new JTextArea("vida más sencilla.");
        JTextArea space2 = new JTextArea();
        JTextArea text3 = new JTextArea("Por favor seleccione alguno de nuestros servicios: ");
        JTextArea space3 = new JTextArea();
        text.setForeground(new Color(238,134,39));
        text2.setForeground(new Color(238,134,39));
        text3.setForeground(new Color(238,134,39));
        text.setBackground(new Color(39,37,37));
        text2.setBackground(new Color(39,37,37));
        text3.setBackground(new Color(39,37,37));
        space.setBackground(new Color(39,37,37));
        space2.setBackground(new Color(39,37,37));
        space3.setBackground(new Color(39,37,37));
        
        setBackground(new Color(39,37,37));
        
        JButton calculadora = new JButton("Calculadora", new ImageIcon(rutaLogoCalculadora));
        
        ActionListenerCalculadora listener3 = new ActionListenerCalculadora();
        calculadora.addActionListener(listener3);
        
        JTextArea space4 = new JTextArea();
        
        JButton dibujo = new JButton("Aplicación de dibujo", new ImageIcon(rutaLogoImagen));
        
        App app = new App();
        ActionListenerDibujo listener2 = new ActionListenerDibujo(app);
        dibujo.addActionListener(listener2);
        
        JTextArea space5 = new JTextArea();
        
        JButton apptexto = new JButton("Editor de Texto", new ImageIcon(rutaLogoTexto));
        
        EditorTexto editorTexto = new EditorTexto();
        ActionListenerTexto listener = new ActionListenerTexto(editorTexto);
        apptexto.addActionListener(listener);
      
        text.setFont(new Font("Verdana",Font.BOLD,13));
        text2.setFont(new Font("Verdana",Font.BOLD,13));
        text3.setFont(new Font("Verdana",Font.BOLD,13));
        
        JTextArea space6 = new JTextArea();
        space4.setBackground(new Color(39,37,37));
        space5.setBackground(new Color(39,37,37));
        space6.setBackground(new Color(39,37,37));
        
        add(space);
        add(text);
        add(text2);
        add(space2);
        add(text3);
        add(space3);
       
        
        
        text.setEditable(false);
        text2.setEditable(false);
        text3.setEditable(false);
        space6.setEditable(false);
        space.setEditable(false);
        space2.setEditable(false);
        space3.setEditable(false);
        space4.setEditable(false);
        space5.setEditable(false);
        
        JPanel panelBotones = new JPanel();
   
        panelBotones.setBackground(new Color(39,37,37));
        panelBotones.add(calculadora);
        panelBotones.add(dibujo);
        panelBotones.add(apptexto);
        
        add(panelBotones);
        
        
        }
    
}
