package office.suite;

import javax.swing.*;
import java.awt.*;
import java.net.*;

public class UserInterface implements Runnable 
{

    private JFrame frame;
   URL rutaLogo = UserInterface.class.getResource("Logo2.png");
    @Override
    public void run() 
    {
        frame = new JFrame("Office Suite V 0.1");
        frame.setPreferredSize(new Dimension(500, 350));
        frame.setLocation(Toolkit.getDefaultToolkit().getScreenSize().width/2-250, Toolkit.getDefaultToolkit().getScreenSize().height/2-175);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        
        createComponents(frame.getContentPane());
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage(rutaLogo));
        frame.setResizable(false);
        frame.pack();
        frame.setVisible(true);
    }

    private void createComponents(Container container) 
    {
        LaminaBotones lamina = new LaminaBotones();
        container.add(lamina);
    }

    public JFrame getFrame() {
        return frame;
    }
}
