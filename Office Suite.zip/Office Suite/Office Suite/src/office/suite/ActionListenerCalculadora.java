/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.suite;

import java.util.GregorianCalendar;
import java.awt.event.*;
import java.io.*;
import javax.swing.SwingUtilities;
import calculadora.*;


/**
 *
 * @author Nicolás
 */
public class ActionListenerCalculadora implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        GregorianCalendar calendar = new GregorianCalendar();
		
		try 
		{
			FileWriter writing = new FileWriter("Historial.txt", true);
			BufferedWriter bw = new BufferedWriter(writing);
			PrintWriter pw = new PrintWriter(bw);
			
			bw.write(calendar.getTime()+"");
			bw.newLine();
				
			bw.close();
			pw.close();
			
		} catch (IOException ex) {
			
			ex.printStackTrace();
		}
		
		InterfazUsuario ui = new InterfazUsuario();
                SwingUtilities.invokeLater(ui);
    }
  

   

    }

    
        
        
        
    

